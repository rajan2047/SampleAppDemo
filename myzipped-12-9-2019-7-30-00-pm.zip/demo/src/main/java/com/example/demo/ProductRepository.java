package com.example.demo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<ProductBO, Integer>{
	
	public List<ProductBO> findByProductColor(String color);
	
	public List<ProductBO> findByProductBrand(String brand);

}
