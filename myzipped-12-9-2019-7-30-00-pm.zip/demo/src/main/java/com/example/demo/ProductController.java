package com.example.demo;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/product")
public class ProductController {

	@Autowired
	private ProductService service;

	@GetMapping(path = "/{color}", produces = "application/json")
	public List<ProductBO> getProductByColor(@PathVariable("color") String color) {
		return service.getProductBasedOnColor(color);
	}
	
	@GetMapping(path = "/{brand}", produces = "application/json")
	public List<ProductBO> getProductByBrand(@PathVariable("brand") String brand) {
		return service.getProductBasedOnBrand(brand);
	}
	
	@PostMapping(path = "/", consumes = "application/json", produces = "application/json")
	public ProductBO getProduct(@RequestBody ProductBO productBO) {
		System.out.println("In getPoduct Method");
		service.saveProduct(productBO);
		return productBO;
	}

}
