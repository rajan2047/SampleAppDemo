package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository ;

	//saving new item
	public String  saveProduct(ProductBO productBO) {
		
		try {
			productRepository.save(productBO);
		} catch (Exception e) {
			// TODO: handle exception
			return "failure";
		}
		
		return "success";
	}
	
	//searching element based on color
	public List<ProductBO> getProductBasedOnColor(String color) {
		return productRepository.findByProductColor(color);
	}
	
	//searching element based on brand
	public List<ProductBO> getProductBasedOnBrand(String brand){
		return productRepository.findByProductBrand(brand);
	}

}
