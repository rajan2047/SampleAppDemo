package com.example.demo.test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.example.demo.ProductBO;
import com.example.demo.ProductService;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class DemoApplicationTests {

	ProductService service = new ProductService();
	ProductBO productBO = new ProductBO();

	@Test
	public void testSaveProduct() {
		System.out.println("Hello");
		assertNotNull(service.saveProduct(productBO), "not null");
	}

}
